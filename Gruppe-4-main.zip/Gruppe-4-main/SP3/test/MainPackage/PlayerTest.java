package MainPackage;

import junit.framework.TestCase;

public class PlayerTest extends TestCase {

    public void testInputFromPlayers() {
    }

    public void testDisplayList() {
    }

    public void testPlayerChoiceInt() {
    }
}